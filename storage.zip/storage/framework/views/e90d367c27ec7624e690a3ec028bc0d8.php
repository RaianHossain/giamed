<?php $__env->startSection('layoutContent'); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('client.partials.inner-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/clientMasterLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/layouts/clientLayout.blade.php ENDPATH**/ ?>