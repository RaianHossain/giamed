<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('client.partials.inner-hero', ['title' => 'Services', 'subtitle' => 'We are here for your care', 'breadCrumb' => 'Services'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main>
        <!-- shop-banner-area start -->
        <section class="shop-banner-area pt-120 pb-120">
            <div class="container">
                <div class="row mt-20">
                    <div class="col-xl-4 col-lg-5 col-md-6">
                        <div class="product-showing mb-40">
                            <p>
                                Showing <?php echo e($services->firstItem()); ?>–<?php echo e($services->lastItem()); ?> of <?php echo e($services->total()); ?> results
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-7 col-md-6">
                        <div class="shop-tab f-right">
                            <ul class="nav text-center" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                        aria-controls="home" aria-selected="true"><i class="fas fa-th-large"></i> </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                                        aria-controls="profile" aria-selected="false"><i class="fas fa-list-ul"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="row">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="product mb-40">
                                            <div class="product__img">
                                                <a href="<?php echo e(route('service-details', ['slug' => $service->slug])); ?>"><img src="<?php echo e(asset('storage/'.$service->avatar)); ?>" alt=""></a>
                                                <div class="product-action text-center">
                                                    <a href="#"><i class="fas fa-shopping-cart"></i></a>
                                                    <a href="#"><i class="fas fa-heart"></i></a>
                                                    <a href="porduct-details.html"><i class="fas fa-expand"></i></a>
                                                </div>
                                            </div>
                                            <div class="product__content text-center pt-30">
                                                <span class="pro-cat"><a href="#">Service</a></span>
                                                <h4 class="pro-title"><a href="<?php echo e(route('service-details', ['slug' => $service->slug])); ?>"><?php echo e($service->title); ?></a></h4>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6">
                                        <div class="product mb-30">
                                            <div class="product__img">
                                                <a href="<?php echo e(route('service-details', ['slug' => $service->slug])); ?>"><img src="<?php echo e(asset('storage/'.$service->avatar)); ?>" alt="<?php echo e($service->title); ?>" class="img-fluid"></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="product-list-content pt-10 mb-30">
                                            <div class="product__content mb-20">
                                                <span class="pro-cat"><a href="#">Service</a></span>
                                                <h4 class="pro-title"><a href="<?php echo e(route('service-details', ['slug' => $service->slug])); ?>"><?php echo e($service->title); ?></a></h4>
                                               
                                            </div>
                                            <p><?php echo e($service->description); ?></p>
                                            <div class="product-action-list">
                                                <a class="btn btn-theme" href="<?php echo e(route('service-details', ['slug' => $service->slug])); ?>">Show Details</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Custom Pagination -->
                <div class="row">
                    <div class="col-12">
                        <div class="basic-pagination basic-pagination-2 text-center mt-20">
                            <ul>
                                <!-- Previous Page Link -->
                                <?php if($services->onFirstPage()): ?>
                                    <li class="disabled"><span><i class="fas fa-angle-double-left"></i></span></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e($services->previousPageUrl()); ?>"><i class="fas fa-angle-double-left"></i></a></li>
                                <?php endif; ?>

                                <!-- Pagination Elements -->
                                <?php $__currentLoopData = $services->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $services->currentPage()): ?>
                                        <li class="active"><span><?php echo e($page); ?></span></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Next Page Link -->
                                <?php if($services->hasMorePages()): ?>
                                    <li><a href="<?php echo e($services->nextPageUrl()); ?>"><i class="fas fa-angle-double-right"></i></a></li>
                                <?php else: ?>
                                    <li class="disabled"><span><i class="fas fa-angle-double-right"></i></span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- shop-banner-area end -->
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clientLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/client/all-services.blade.php ENDPATH**/ ?>