<?php $__env->startSection('title', $service->title); ?>

<?php $__env->startSection('content'); ?>
    <!-- Service Hero Section -->
    <?php echo $__env->make('client.partials.inner-hero', [
        'subtitle' => 'We are here for your care.',
        'title' => $service->title,
        'breadCrumb' => 'Details',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Service Details Area -->
    <div class="service-details-area pt-120 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-xl-7 col-lg-8">
                    <?php echo $__env->make('client.partials.service-details.details', ['service' => $service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="col-xl-5 col-lg-4">
                    <?php echo $__env->make('client.partials.service-details.other-services', ['otherServices' => $otherServices], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->make('client.partials.service-details.get-some-advice', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="service-widget mb-50 border-0 p-0">
                        <div class="banner-widget">
                            <a href="#">
                                <!-- <img src="assets/img/services/services-banner.png" alt=""> -->
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service Details Area End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clientLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/client/service-details.blade.php ENDPATH**/ ?>