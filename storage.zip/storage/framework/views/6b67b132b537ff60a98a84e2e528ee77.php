<?php $__env->startSection('title', 'Appointments - Index'); ?>

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href=<?php echo e(route('dashboard-analytics')); ?>>Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Appointments</li>
    </ol>
</nav>

<div class="row mb-4">
  <div class="col-4">
      <div class="card">
          <div class="card-body">
              <h6>Appointments</h6>
              <p><?php echo e($total_appointments ?? 0); ?></p>
              <p>Total Appointments</p>
          </div>
      </div>        
  </div>  
</div>

<!-- Appointments Table -->
<div class="card overflow-hidden">
  <div class="d-flex justify-content-between align-items-center">
      <h5 class="card-header m-0">Appointments</h5>
  </div>
  <div class="table-responsive text-nowrap">
    <table class="table table-dark">
        <thead>
            <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Date</th>
                <th>Time</th>
                <th>Special Request</th>
                <th>Status</th>
                <th>IP Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-id="<?php echo e($appointment->id); ?>">
                    <td><?php echo e($appointment->name); ?></td>
                    <td><?php echo e($appointment->phone); ?></td>
                    <td><?php echo e($appointment->date); ?></td>
                    <td><?php echo e($appointment->time); ?></td>
                    <td><?php echo e($appointment->special_request); ?></td>
                    <td>
                        <select class="form-select status-select" data-original="<?php echo e($appointment->status); ?>" style="width: 120px; color: #d6d2d2;">
                            <option value="pending" <?php echo e($appointment->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="confirmed" <?php echo e($appointment->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                            <option value="canceled" <?php echo e($appointment->status == 'canceled' ? 'selected' : ''); ?>>Canceled</option>
                        </select>
                    </td>
                    <td><?php echo e($appointment->ip_address); ?></td>
                    <td>
                        <button class="btn btn-sm btn-warning update-status-btn" disabled>
                            <i class="ri-pencil-line me-1"></i> Update
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('tbody tr').forEach(row => {
        const select = row.querySelector('.status-select');
        const updateBtn = row.querySelector('.update-status-btn');

        // Enable update button on change
        select.addEventListener('change', () => {
            updateBtn.disabled = select.value === select.getAttribute('data-original');
        });

        // Handle update button click
        updateBtn.addEventListener('click', () => {
            const appointmentId = row.getAttribute('data-id');
            const newStatus = select.value;

            fetch(`/dashboard/appointments/${appointmentId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ status: newStatus })
            })
            .then(response => {
                if (!response.ok) throw new Error('Request failed');
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    select.setAttribute('data-original', newStatus);
                    updateBtn.disabled = true;
                    alert(data.message || 'Status updated successfully');
                } else {
                    alert('Update failed');
                }
            })
            .catch(error => {
                console.error(error);
                alert('Error updating status.');
            });
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/appointments/index.blade.php ENDPATH**/ ?>