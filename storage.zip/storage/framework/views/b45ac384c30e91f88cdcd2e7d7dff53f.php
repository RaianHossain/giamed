<?php $__env->startSection('title', ' Services - Index'); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href=<?php echo e(route('dashboard-analytics')); ?>>Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Categories</li>
    </ol>
</nav>

<div class="row mb-4">
  <div class="col-4">
      <div class="card">
          <div class="card-body">
              <h6>Categories</h6>
              <p><?php echo e($total_categories ?? 0); ?></p>
              <p>Total Categories</p>
          </div>
      </div>        
  </div>  
</div>

<!-- Bootstrap Dark Table -->
<div class="card overflow-hidden">
  <div class="d-flex justify-content-between align-items-center">
      <h5 class="card-header m-0">Categories</h5>
      <button type="button" class="btn btn-success me-3 text-white" data-bs-toggle="offcanvas" data-bs-target="#addCategoryCanvas">
          <span class="tf-icons ri-add-line ri-16px me-1"></span>Add New
      </button>
  </div>
  <div class="table-responsive text-nowrap">
    <table class="table table-dark">
      <thead>
        <tr>
          <th>Title</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <!-- Title -->
              <td><?php echo e($category->title); ?></td>

              <!-- Description -->
              <td><?php echo e($category->description); ?></td>

              <!-- Actions -->
              <td>
                  <div class="dropdown">
                      <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                          <i class="ri-more-2-line"></i>
                      </button>
                      <div class="dropdown-menu">
                          <!-- Edit Button -->
                          <a class="dropdown-item">
                              <button class="btn btn-sm btn-warning edit-category-btn fixed-width"
                                  data-id="<?php echo e($category->id); ?>"
                                  data-title="<?php echo e($category->title); ?>"
                                  data-description="<?php echo e($category->description); ?>"
                                  data-bs-toggle="modal"
                                  data-bs-target="#editCategoryModal">
                                  <i class="ri-pencil-line me-1"></i> Edit
                              </button>
                          </a>

                          <!-- Delete Button -->
                          <a class="dropdown-item" href="javascript:void(0);">
                              <button class="btn btn-sm btn-danger delete-category-btn fixed-width"
                                  data-id="<?php echo e($category->id); ?>"
                                  data-bs-toggle="modal"
                                  data-bs-target="#deleteCategoryModal">
                                  <i class="ri-delete-bin-6-line me-1"></i>Delete
                              </button>
                          </a>
                      </div>
                  </div>
              </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Category Offcanvas -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="addCategoryCanvas" aria-labelledby="addCategoryCanvasLabel">
  <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="addCategoryCanvasLabel">Add New Category</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
      <form action="<?php echo e(route('dashboard-categories-store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <!-- Title Field -->
          <div class="mb-3">
              <label for="title" class="form-label">Title</label>
              <input type="text" class="form-control" id="title" name="title" required>
          </div>

          <!-- Description Field -->
          <div class="mb-3">
              <label for="description" class="form-label">Description</label>
              <textarea class="form-control" id="description" name="description" rows="3"></textarea>
          </div>

          <!-- Submit Button -->
          <button type="submit" class="btn btn-primary">Save</button>
      </form>
  </div>
</div>

<!-- Edit Category Modal -->
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="editCategoryModalLabel">Edit Category</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              <form id="editCategoryForm" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?> <!-- Hidden field to override the method to PUT -->
                  
                  <!-- Title Field -->
                  <div class="mb-3">
                      <label for="editTitle" class="form-label">Title</label>
                      <input type="text" class="form-control" id="editTitle" name="title" required>
                  </div>

                  <!-- Description Field -->
                  <div class="mb-3">
                      <label for="editDescription" class="form-label">Description</label>
                      <textarea class="form-control" id="editDescription" name="description" rows="3"></textarea>
                  </div>

                  <!-- Submit Button -->
                  <button type="submit" class="btn btn-primary">Update</button>
              </form>
          </div>
      </div>
  </div>
</div>

<!-- Delete Category Modal -->
<div class="modal fade" id="deleteCategoryModal" tabindex="-1" aria-labelledby="deleteCategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="deleteCategoryModalLabel">Delete Category</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              <p>Are you sure you want to delete this category?</p>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <form id="deleteCategoryForm" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-danger">Delete</button>
              </form>
          </div>
      </div>
  </div>
</div>

<!-- JavaScript for Edit and Delete Modals -->
<script>
  // Edit Modal
document.querySelectorAll('.edit-category-btn').forEach(button => {
    button.addEventListener('click', () => {
        const id = button.getAttribute('data-id');
        const title = button.getAttribute('data-title');
        const description = button.getAttribute('data-description');

        document.getElementById('editTitle').value = title;
        document.getElementById('editDescription').value = description;
        document.getElementById('editCategoryForm').action = `/dashboard/categories/${id}`;
    });
});

// Delete Modal
document.querySelectorAll('.delete-category-btn').forEach(button => {
    button.addEventListener('click', () => {
        const id = button.getAttribute('data-id');
        document.getElementById('deleteCategoryForm').action = `/dashboard/categories/${id}`;
    });
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/content/categories/index.blade.php ENDPATH**/ ?>