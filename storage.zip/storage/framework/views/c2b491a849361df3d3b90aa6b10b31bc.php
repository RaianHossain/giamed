<div class="service-widget mb-50">
    <!-- Widget Title -->
    <div class="widget-title-box mb-30">
        <h3 class="widget-title">Other Services</h3>
    </div>

    <!-- More Service List -->
    <div class="more-service-list">
        <ul>
            <?php $__currentLoopData = $otherServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('service-details', ['slug' => $service->slug])); ?>">
                    <div class="more-service-icon">
                        <img src="<?php echo e(asset('storage/'.$service->avatar)); ?>" alt="<?php echo e($service->title); ?>">
                    </div>
                    <div class="more-service-title">
                        <?php echo e($service->title); ?>

                    </div>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="text-center mt-5">
            <a href="<?php echo e(route('all-services')); ?>" class="text-primary">See all</a>            
        </div>
    </div>
</div><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/client/partials/service-details/other-services.blade.php ENDPATH**/ ?>