<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('layoutContent'); ?>
    <main>
        <!-- hero-area start -->
        <?php echo $__env->make('client.partials.home.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- hero-area end -->

        <!-- about-area start -->
        <?php echo $__env->make('client.partials.home.home-about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- about-area end -->

        <!-- services-area start -->
        <?php echo $__env->make('client.partials.home.home-services', ['services' => $services], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- services-area end -->

        <!-- facts start -->
        <?php echo $__env->make('client.partials.home.home-fact', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- facts end -->

        <!-- team-area start -->
        <?php echo $__env->make('client.partials.home.home-brands', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>;
        <!-- team-area end -->

        <!-- trust-us-area start -->
        <?php echo $__env->make('client.partials.home.home-trust-us', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>;
        <!-- trust-us-area end -->

        <!-- blog-area start -->
        
        <!-- blog-area end -->
        
        
        <div style='height: 200px;'></div>
        <!-- Footer -->
        <?php echo $__env->make('client.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.clientMasterLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/client/home.blade.php ENDPATH**/ ?>