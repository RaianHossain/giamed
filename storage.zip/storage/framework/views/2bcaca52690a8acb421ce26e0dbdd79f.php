<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('client.partials.inner-hero', ['title' => 'About Us', 'subtitle' => 'We are here for your care', 'breadCrumb' => 'About'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main>
        <?php echo $__env->make('client.partials.about.about-details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('client.partials.about.about-counter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('client.partials.about.about-contact', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('client.partials.about.about-teams', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('client.partials.about.about-testimonials', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clientLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/GiaMedical_New_Vite/resources/views/client/about.blade.php ENDPATH**/ ?>